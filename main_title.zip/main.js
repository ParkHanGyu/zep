App.onJoinPlayer.Add(function(player){
    player.moveSpeed = 300;
    player.title = "셜록이형아";
    player.sendUpdated();
})